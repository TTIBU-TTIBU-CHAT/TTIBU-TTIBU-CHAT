import * as S from './SubmitButton.styles'

export default function SubmitButton({ children }) {
  return <S.Button type="submit">{children}</S.Button>
}
